@echo off
chcp 65001 >nul
echo ================================================
echo   打包项目到桌面
echo ================================================
echo.

set "source=e:\Trae CN\store\Agent\literature_agent_system"
set "dest=%USERPROFILE%\Desktop\literature-agent-system.zip"

echo 正在打包...
powershell -Command "Compress-Archive -Path '%source%\*' -DestinationPath '%dest%' -Force"

if %errorlevel% equ 0 (
    echo.
    echo ================================================
    echo   打包成功！
    echo ================================================
    echo.
    echo 文件位置：%dest%
    echo.
    echo 按任意键打开文件所在位置...
    pause >nul
    explorer /select,"%dest%"
) else (
    echo.
    echo ================================================
    echo   打包失败！
    echo ================================================
    echo.
    pause
)
